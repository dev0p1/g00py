import random, os, string, sys
import argparse
import socket
import requests
from playwright.sync_api import sync_playwright
import time
import user_agnt
# from read_mail import get_code

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
PROXY_FILE      = os.path.join(BASE_DIR, "proxies.txt")
USED_PROXY_FILE = os.path.join(BASE_DIR, "used_proxies.txt")
REQUEST_TIMEOUT = 15

def _test_proxy(proxy: str, timeout: int) -> bool:
    for url in ["http://api.ipify.org", "http://httpbin.org/ip", "http://ifconfig.me/ip"]:
        try:
            r = requests.get(url, proxies={"http": proxy, "https": proxy}, timeout=timeout)
            if r.status_code == 200:
                return True
        except Exception:
            continue
    return False

def get_working_proxy(proxy_list, timeout=REQUEST_TIMEOUT) -> str:
    from concurrent.futures import ThreadPoolExecutor, as_completed
    random.shuffle(proxy_list)
    print(f"[~] Testing {len(proxy_list)} proxies...")
    working = []
    with ThreadPoolExecutor(max_workers=min(len(proxy_list), 20)) as ex:
        futures = {ex.submit(_test_proxy, p, timeout): p for p in proxy_list}
        for f in as_completed(futures):
            if f.result():
                working.append(futures[f])
    if not working:
        raise RuntimeError("No working proxies available!")
    chosen = random.choice(working)
    print(f"✅ {len(working)} working | 🎯 Selected: {chosen}")
    return chosen

def mark_proxy_used(proxy: str):
    with open(PROXY_FILE) as f:
        lines = [l.strip() for l in f if l.strip()]
    remaining = [l for l in lines if not (l == proxy or f"http://{l}" == proxy or l == proxy.replace("http://", ""))]
    with open(PROXY_FILE, "w") as f:
        f.write("\n".join(remaining) + ("\n" if remaining else ""))
    with open(USED_PROXY_FILE, "a") as f:
        f.write(proxy + "\n")
    print(f"[~] Proxy moved to used: {proxy}")

def get_ip_info(proxy_url: str = None, retries: int = 6, delay: int = 5) -> dict:
    proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
    urls = ["http://ipwho.is/", "http://ip-api.com/json", "http://api.ipify.org?format=json"]
    for attempt in range(retries):
        for url in urls:
            try:
                r = requests.get(url, timeout=10, proxies=proxies)
                data = r.json()
                if data.get("ip") or data.get("query"):
                    data.setdefault("ip", data.get("query"))
                    data.setdefault("country_code", data.get("countryCode", "US"))
                    return data
            except Exception as e:
                print(f"[-] IP lookup failed ({url}): {e}")
        print(f"[~] Tor not ready yet, retrying in {delay}s... ({attempt+1}/{retries})")
        time.sleep(delay)
    return {}

# country_code -> (locale, timezone, accept-language header value)
CC_LANG = {
    "US": ("en-US", "America/New_York",   "en-US,en;q=0.9"),
    "GB": ("en-GB", "Europe/London",      "en-GB,en;q=0.9"),
    "IT": ("it-IT", "Europe/Rome",        "it-IT,it;q=0.9,en;q=0.8"),
    "DE": ("de-DE", "Europe/Berlin",      "de-DE,de;q=0.9,en;q=0.8"),
    "FR": ("fr-FR", "Europe/Paris",       "fr-FR,fr;q=0.9,en;q=0.8"),
    "ES": ("es-ES", "Europe/Madrid",      "es-ES,es;q=0.9,en;q=0.8"),
    "NL": ("nl-NL", "Europe/Amsterdam",   "nl-NL,nl;q=0.9,en;q=0.8"),
    "PL": ("pl-PL", "Europe/Warsaw",      "pl-PL,pl;q=0.9,en;q=0.8"),
    "BR": ("pt-BR", "America/Sao_Paulo",  "pt-BR,pt;q=0.9,en;q=0.8"),
    "RU": ("ru-RU", "Europe/Moscow",      "ru-RU,ru;q=0.9,en;q=0.8"),
    "TR": ("tr-TR", "Europe/Istanbul",    "tr-TR,tr;q=0.9,en;q=0.8"),
    "JP": ("ja-JP", "Asia/Tokyo",         "ja-JP,ja;q=0.9,en;q=0.8"),
    "CN": ("zh-CN", "Asia/Shanghai",      "zh-CN,zh;q=0.9,en;q=0.8"),
    "SE": ("sv-SE", "Europe/Stockholm",   "sv-SE,sv;q=0.9,en;q=0.8"),
    "MX": ("es-MX", "America/Mexico_City","es-MX,es;q=0.9,en;q=0.8"),
}

_parser = argparse.ArgumentParser(add_help=False)
_parser.add_argument("-T", "--tor",        action="store_true")
_parser.add_argument("-P", "--proxy",      action="store_true")
_parser.add_argument("--debug",            action="store_true")
_parser.add_argument("--socks-port",       type=int, default=9050)
_parser.add_argument("--control-port",     type=int, default=9051)
_args, _ = _parser.parse_known_args()

DEBUG        = _args.debug
HEADLESS     = not DEBUG
CANVA_URL    = "https://www.canva.com/login"
TOR_PROXY    = f"socks5://127.0.0.1:{_args.socks_port}"
CONTROL_PORT = _args.control_port

def send_signal(signal: str):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect(("127.0.0.1", CONTROL_PORT))
            s.sendall(b'AUTHENTICATE ""\r\n')
            auth_resp = b""
            while b"\r\n" not in auth_resp:
                auth_resp += s.recv(1024)
            if b"250" not in auth_resp:
                return False, f"Auth failed: {auth_resp.decode()}"
            s.sendall(f"SIGNAL {signal}\r\n".encode())
            sig_resp = b""
            while b"\r\n" not in sig_resp:
                sig_resp += s.recv(1024)
            return b"250" in sig_resp, sig_resp.decode().strip()
    except Exception as e:
        return False, str(e)

def wait_for_tor(timeout: int = 60, interval: int = 3):
    """Block until Tor reports 100% bootstrap via control port."""
    print(f"[~] Waiting for Tor on control port {CONTROL_PORT}...")
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(5)
                s.connect(("127.0.0.1", CONTROL_PORT))
                s.sendall(b'AUTHENTICATE ""\r\n')
                s.recv(1024)
                s.sendall(b'GETINFO status/bootstrap-phase\r\n')
                resp = s.recv(4096).decode()
                if "PROGRESS=100" in resp:
                    print(f"[+] Tor ready on port {CONTROL_PORT}")
                    return True
                progress = next((p.split("=")[1] for p in resp.split() if p.startswith("PROGRESS=")), "?")
                print(f"[~] Tor bootstrap: {progress}%")
        except Exception as e:
            print(f"[~] Control port not ready: {e}")
        time.sleep(interval)
    print(f"[-] Tor did not bootstrap in {timeout}s")
    return False

def tor_reset_and_get_ip():
    wait_for_tor()
    ok, msg = send_signal("NEWNYM")
    if not ok:
        print(f"[-] Tor NEWNYM failed: {msg}")
    time.sleep(5)
    return get_ip_info(TOR_PROXY).get("ip", "unknown")

LOG_FILE = os.path.join(BASE_DIR, "ip_log.txt")

def log_ip(ip: str):
    with open(LOG_FILE, "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {ip}\n")

DOMAINS = [
    "bitcoin-plazza.eu.org",
    "itchigho.eu.org",
    "techxbox.eu.org",
    "youoneshell.eu.org",
]

def generate_identity():
    name   = ''.join(random.choices(string.ascii_lowercase, k=8))
    number = random.randint(1000, 9999)
    email  = f"kalawssimatrix+{number}@gmail.com"
    print("=" * 40)
    print(f"  Name : {name}")
    print(f"  Email: {email}")
    print("=" * 40)
    return name, email

viewports = [
    {"width": 1920, "height": 1080},
    {"width": 1366, "height": 768},
    {"width": 1536, "height": 864},
    {"width": 1440, "height": 900},
    {"width": 1280, "height": 720},
]

def run_session(elements: dict, session_id: int = 0, proxy_config: dict = None):
    if _args.tor:
        tor_ip = tor_reset_and_get_ip()
        log_ip(tor_ip)
        proxy_config = proxy_config or {"server": TOR_PROXY}
    else:
        tor_ip = "N/A"
        proxy_config = proxy_config or {}

    # resolve IP info and match locale/tz to the proxy's country
    proxy_url = proxy_config.get("server") if proxy_config else None
    ip_info   = get_ip_info(proxy_url)
    cc        = (ip_info.get("country_code") or "US").upper()
    locale, chosen_tz, accept_lang = CC_LANG.get(cc, CC_LANG["US"])
    lang_primary = locale
    lang_base    = locale.split("-")[0]
    print(f"[~] IP: {ip_info.get('ip')} | {ip_info.get('country')} ({cc}) → locale={locale} tz={chosen_tz}")
    os.environ["TZ"] = chosen_tz
    time.tzset()

    session_profile = os.path.join(BASE_DIR, f"playwright-profile-{session_id}")
    os.makedirs(session_profile, exist_ok=True)

    with sync_playwright() as p:
        browser_type    = p.chromium
        chosen_viewport = random.choice(viewports)
        chrome_ua       = user_agnt.get_ua(browser_type.name)

        EMAIL = elements.get("email")
        NAME  = elements.get("name", "N/A")

        print("\n" + "═" * 52)
        print(f"  SESSION #{session_id}")
        print("═" * 52)
        print(f"  {'Name':<14}: {NAME}")
        print(f"  {'Email':<14}: {EMAIL}")
        print(f"  {'Browser':<14}: {browser_type.name}")
        print(f"  {'Proxy':<14}: {TOR_PROXY}")
        print(f"  {'Tor IP':<14}: {tor_ip}")
        print(f"  {'User-Agent':<14}: {chrome_ua[:55]}...")
        print(f"  {'Viewport':<14}: {chosen_viewport['width']}x{chosen_viewport['height']}")
        print(f"  {'Timezone':<14}: {chosen_tz}")
        print(f"  {'Headless':<14}: {HEADLESS}")
        print("═" * 52 + "\n")

        os.system(f'rm -rf "{session_profile}"/*')

        # detect if Google Chrome is available, fall back to Chromium
        chrome_bin = "/usr/bin/google-chrome"
        launch_kwargs = dict(
            headless=True,
            proxy=proxy_config,
            user_agent=chrome_ua,
            viewport=chosen_viewport,
            locale=locale,
            timezone_id=chosen_tz,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-infobars",
                "--disable-dev-shm-usage",
                "--window-size=1920,1080",
            ],
            ignore_default_args=["--enable-automation"],
        )
        if os.path.exists(chrome_bin):
            launch_kwargs["channel"] = "chrome"

        context = browser_type.launch_persistent_context(session_profile, **launch_kwargs)
        page = context.pages[0] if context.pages else context.new_page()

        page.add_init_script(f"""
            Object.defineProperty(navigator, 'webdriver', {{ get: () => undefined }});
            window.chrome = {{ runtime: {{}} }};
            Object.defineProperty(navigator, 'plugins',   {{ get: () => [1, 2, 3] }});
            Object.defineProperty(navigator, 'languages', {{ get: () => ['{lang_primary}', '{lang_base}'] }});
            Object.defineProperty(navigator, 'language',  {{ get: () => '{lang_primary}' }});
            Object.defineProperty(Intl, 'DateTimeFormat', {{
                value: new Proxy(Intl.DateTimeFormat, {{
                    construct(target, args) {{
                        if (!args[0]) args[0] = '{locale}';
                        return new target(...args);
                    }}
                }})
            }});
            Object.defineProperty(window, 'outerHeight', {{ get: () => window.innerHeight }});
            Object.defineProperty(window, 'outerWidth',  {{ get: () => window.innerWidth  }});
        """)

        mohmal_url = f"https://mohmal.eu.org/?{EMAIL}"
        page.goto(mohmal_url, wait_until="domcontentloaded", timeout=60000)
        time.sleep(2)

        # Click first iframe, go back, click second iframe
        iframes = page.frames[1:]  # skip main frame
        for i, frame in enumerate(iframes[:2]):
            try:
                frame.click("body", timeout=13000)
                print(f"[+] Clicked iframe #{i+1}: {frame.url[:60]}")
                time.sleep(1)
                try:
                    text = frame.locator("body").inner_text(timeout=5000).strip()
                    if text:
                        print(f"[📄] iframe #{i+1} text: {text[:300]}")
                except Exception:
                    pass
            except Exception as e:
                print(f"[-] iframe #{i+1} click failed: {e}")
            if i == 0:
                page.bring_to_front()
                time.sleep(1)

        page.bring_to_front()
        time.sleep(10)

        # Print titles of all open tabs
        all_pages = context.pages
        for i, pg in enumerate(all_pages):
            print(f"[tab {i}] title: {pg.title()}")

        # Switch to second tab if exists
        if len(all_pages) > 1:
            second_tab = all_pages[1]
            second_tab.bring_to_front()
            print(f"[+] Switched to tab 1: {second_tab.title()}")
            time.sleep(2)
            # Switch back to main tab
            page.bring_to_front()
            print(f"[+] Back to tab 0: {page.title()}")

        # Interact with mohmal app frame
        target_handler = page
        for frame in page.frames:
            if "2420628" in frame.url and frame != page.main_frame:
                target_handler = frame
                print(f"[+] Found app frame: {frame.url}")
                break
        try:
            button = target_handler.locator("button:has-text('Random'), a:has-text('Create'), #create-email")
            button.wait_for(state="visible", timeout=15000)
            button.click()
            print("[+] Clicked the create button.")
        except Exception as e:
            print(f"[-] Failed to click mohmal button: {e}")
            page.screenshot(path=os.path.join(BASE_DIR, f"debug_{session_id}_mohmal.png"))
        time.sleep(20)

       

        # time.sleep(5)
        print(f"[session {session_id}] Current URL: {page.url}")

        page.close()
        context.close()


# --- entry point ---
if not _args.tor and not _args.proxy:
    print("[-] Specify -T (Tor) or -P (proxy). Exiting.")
    sys.exit(1)

proxy_config = None
if _args.proxy:
    with open(PROXY_FILE) as f:
        proxies = [l.strip() if "://" in l.strip() else f"http://{l.strip()}" for l in f if l.strip()]
    if not proxies:
        print("[~] proxies.txt empty — restoring from used_proxies.txt")
        with open(USED_PROXY_FILE) as f:
            proxies = [l.strip() for l in f if l.strip()]
        with open(PROXY_FILE, "w") as f:
            f.write("\n".join(proxies) + "\n")
        open(USED_PROXY_FILE, "w").close()
        print(f"[~] Restored {len(proxies)} proxies")
    proxy_url = get_working_proxy(proxies)
    mark_proxy_used(proxy_url)
    print(f"[~] Using proxy: {proxy_url}")
    proxy_config = {"server": proxy_url}

name, email_addr = generate_identity()
session_id = _args.socks_port  # unique per instance
run_session(elements={"email": email_addr, "name": name}, session_id=session_id, proxy_config=proxy_config)
os.system(f'rm -rf playwright-profile-{session_id}')
