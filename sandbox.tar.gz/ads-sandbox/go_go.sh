#!/bin/bash
apt-get update -y
apt-get install -y tor torsocks python3-pip
pip3 install -r requirements.txt
playwright install chrome
playwright install-deps


mkdir content/
#nohup tor -f torrc1 >/dev/null 2>&1 &
#nohup tor -f torrc2 >/dev/null 2>&1 &
#nohup tor -f torrc3 >/dev/null 2>&1 &
setsid tor -f torrc1 >content/tor1.log 2>&1 &
setsid tor -f torrc2 >content/tor2.log 2>&1 &
setsid tor -f torrc3 >content/tor3.log 2>&1 &
setsid tor -f torrc4 >content/tor4.log 2>&1 &
setsid tor -f torrc5 >content/tor5.log 2>&1 &
setsid tor -f torrc6 >content/tor6.log 2>&1 &
# wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
# apt install -y ./google-chrome-stable_current_amd64.deb
echo "Start"
sleep 15
echo "Done after 10 seconds"

run_loop() {
    local socks=$1 ctrl=$2
    while true; do
        python3 thor_main.py -T --socks-port "$socks" --control-port "$ctrl"
        sleep 2
    done
}

run_loop 9050 9051 &
run_loop 9052 9053 &
run_loop 9054 9055 &
run_loop 9056 9057 &
run_loop 9058 9059 &
run_loop 9060 9061 &
wait
